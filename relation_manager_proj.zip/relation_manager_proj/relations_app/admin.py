from django.contrib import admin
from .models import *
admin.site.register(user)
admin.site.register(student)
admin.site.register(user1)
admin.site.register(student1)
admin.site.register(man)
# Register your models here.
