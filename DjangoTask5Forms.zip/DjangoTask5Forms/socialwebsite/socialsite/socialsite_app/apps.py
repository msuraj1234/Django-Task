from django.apps import AppConfig


class SocialsiteAppConfig(AppConfig):
    name = 'socialsite_app'
