from django.apps import AppConfig


class EmpregAppConfig(AppConfig):
    name = 'empreg_app'
