from django import forms

class EmpForm(forms.Form):
    emp_id = forms.IntegerField()
    f_name = forms.CharField(max_length=20)
    m_name = forms.CharField(max_length=20)
    l_name = forms.CharField(max_length=20)
    dept = forms.CharField(max_length=20)
    phone = forms.IntegerField()
    email = forms.EmailField()
    address = forms.CharField(widget=forms.Textarea)