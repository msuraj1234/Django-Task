from .models import EmpReg
from django.shortcuts import render
from .forms import EmpForm

# Create your views here.
def empindex(request):
    emp_details = EmpReg.objects.all()
    return render(request,'empreg_app/emp.html', {'emp':emp_details})

def empindex2(request):
    if request.method == 'POST':
        form = EmpForm(request.POST)
        if form.is_valid():
            emp_id = form.cleaned_data.get("emp_id")
            f_name = form.cleaned_data.get("f_name")
            m_name = form.cleaned_data.get("m_name")
            l_name = form.cleaned_data.get("l_name")
            dept = form.cleaned_data.get("dept")
            phone = form.cleaned_data.get("phone")
            email = form.cleaned_data.get("email")
            address = form.cleaned_data.get("address")
            emp_save = EmpReg(emp_id = emp_id, f_name = f_name,m_name = m_name,l_name = l_name, dept = dept,phone = phone, email = email, address = address)
            emp_save.save()
        return render(request, 'empreg_app/emp2.html', {'form':form})
    else:
        form = EmpForm()
        return render(request, 'empreg_app/emp2.html', {'form':form})
