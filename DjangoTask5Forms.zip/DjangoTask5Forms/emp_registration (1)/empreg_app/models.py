from django.db import models

# Create your models here.
class EmpReg(models.Model):
    emp_id = models.IntegerField()
    f_name = models.CharField(max_length=20,default='SOME STRING')
    m_name = models.CharField(max_length=20,default='SOME STRING')
    l_name = models.CharField(max_length=20,default='SOME STRING')
    dept = models.CharField(max_length=20)
    phone = models.IntegerField(default=None)
    email = models.EmailField(default=None)
    address = models.CharField(max_length = 50,default='SOME STRING')
    