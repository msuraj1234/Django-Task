from django.apps import AppConfig


class MedicalAppConfig(AppConfig):
    name = 'medical_app'
