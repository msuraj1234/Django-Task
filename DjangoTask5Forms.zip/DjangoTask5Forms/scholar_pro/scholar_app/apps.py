from django.apps import AppConfig


class ScholarAppConfig(AppConfig):
    name = 'scholar_app'
