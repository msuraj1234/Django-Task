from django.shortcuts import render
from .forms import UserForm
from .forms import UserRegForm


# Create your views here.
# def index(request):
#     if request.method == "POST":
#         form = UserForm(request.POST)
#         if form.is_valid():
#             nae = form.cleaned_data['name']
#             emal = form.cleaned_data['email']
#             passwod = form.cleaned_data['password']
#             phon = form.cleaned_data['phone']
#         return render(request, 'index.html', {'form':form})
#     else:
#         form = UserForm()
#         return render(request, 'index.html',{'form':form})


def index(request):
    if request.method == "POST":
        form = UserRegForm(request.POST)
        if form.is_valid():
            nae = form.cleaned_data['name']
            emal = form.cleaned_data['email']
            passwod = form.cleaned_data['password']
            phon = form.cleaned_data['phone']
        return render(request, 'index.html', {'form':form})
    else:
        form = UserRegForm()
        return render(request, 'index.html',{'form':form})