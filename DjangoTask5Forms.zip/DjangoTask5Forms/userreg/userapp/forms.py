from django import forms
from .models import UserReg

class UserForm(forms.Form):
    name = forms.CharField(label='Enter Name',initial='Mr./Mrs.')
    email = forms.EmailField(label='Enter Email')
    password = forms.CharField(label='Enter Password',widget=forms.PasswordInput)
    phone = forms.IntegerField(label='Enter Phone')



class UserRegForm(forms.ModelForm):
    class Meta:
        model = UserReg
        fields = ('name','email','password','phone')

    field_order = ['email','name', 'phone','password']