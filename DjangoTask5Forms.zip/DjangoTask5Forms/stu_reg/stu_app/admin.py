from django.contrib import admin
from .models import StudentReg

# Register your models here.
admin.site.register(StudentReg)