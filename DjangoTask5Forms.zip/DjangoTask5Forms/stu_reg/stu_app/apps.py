from django.apps import AppConfig


class StuAppConfig(AppConfig):
    name = 'stu_app'
