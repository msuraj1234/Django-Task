from django.shortcuts import render

from app1.models import student

# Create your views here.
def get_data(request):
    #data = student.objects.all()
    #data = student.objects.filter(city="Allagadda")
    #data = student.objects.exclude(city='Allagadda')
    #data = student.objects.order_by('name')
    #data = student.objects.order_by('?')
    # data = student.objects.order_by('name').reverse()[0:4]
    #data = student.objects.values()
    # data = student.objects.values('name','city')
    #data = student.objects.values_list()
    #data = student.objects.values_list('name','city')
    # data = student.objects.values_list('name','city',named=True)
    data = student.objects.using('default')



    print("---------------------")
    print('Return',data)
    print("--------------------")
    print("Sql Query :-",data.query)

    return render(request,'get.html',{'data':data})