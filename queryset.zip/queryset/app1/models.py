from django.db import models

# Create your models here.

class student(models.Model):
    name = models.CharField(max_length=200)
    sno = models.IntegerField(unique=True)
    mob = models.IntegerField(unique=True)
    email = models.EmailField()
    city = models.CharField(max_length=100)
