from django.contrib import admin
from .models import Student
from .models import Teacher
from .models import Contractor

# Register your models here.

class StudentAdmin(admin.ModelAdmin):
    list_display = ['name','age','subject']
admin.site.register(Student,StudentAdmin)


class TeacherAdmin(admin.ModelAdmin):
    list_display = ['name','age','salary']
admin.site.register(Teacher,TeacherAdmin)


class ContractorAdmin(admin.ModelAdmin):
    list_display = ['name','age','ph']
admin.site.register(Contractor,ContractorAdmin)
