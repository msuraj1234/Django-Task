from django.db import models

# Create your models here.
class CommonAbs(models.Model):
    name = models.CharField(max_length=20)
    age = models.IntegerField()
    date = models.DateField()

    class Meta:

        abstract = True

class Student(CommonAbs):
    subject = models.CharField(max_length=20)
    date = None

class Teacher(CommonAbs):
    date = models.DateTimeField()
    salary = models.FloatField()

class Contractor(CommonAbs):
    ph = models.IntegerField()
