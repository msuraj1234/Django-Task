from django.shortcuts import render
from .models import Student
from .models import Teacher
from .models import Contractor

# Create your views here.
def student(request):
    student = Student.objects.all()
    teacher = Teacher.objects.all()
    contractor = Contractor.objects.all()
    return render(request,'index.html',{'student':student,'teacher':teacher,'contractor':contractor})

