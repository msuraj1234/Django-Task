from django.contrib import admin
from .models import TicketBookModel

# Register your models here.
admin.site.register(TicketBookModel)