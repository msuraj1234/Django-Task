from django import forms
from .models import TicketBookModel

class Ticket_forms(forms.ModelForm):
    class Meta:
        model = TicketBookModel
        fields = '__all__'