from django.shortcuts import render, redirect
from .forms import Ticket_forms
from .models import TicketBookModel

# Create your views here.
def show(request):
    if request.method == 'POST':
        form = Ticket_forms(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            movie_name = form.cleaned_data['movie_name']
            email = form.cleaned_data['email']
            ticket_no = form.cleaned_data['ticket_no']
            no_of_tickets = form.cleaned_data['no_of_tickets']
            reg_data = TicketBookModel(name=name,movie_name=movie_name,email=email,ticket_no=ticket_no,no_of_tickets=no_of_tickets)
            reg_data.save()
            form = Ticket_forms()
    else:
        form = Ticket_forms()
    booking = TicketBookModel.objects.all()
    total = 100
    instance = TicketBookModel.objects.values_list('no_of_tickets')
    description = sum(map(sum, instance))
    available = total - description
    return render(request, 'show.html', {'form': form, 'book':booking,'total':total, 'booked':description, 'remain':available})

def update_ticket(request, id):
    ticket = TicketBookModel.objects.get(pk=id)  
    form = Ticket_forms(request.POST, instance = ticket)
    instance = TicketBookModel.objects.values_list('no_of_tickets')[0]
    description = instance[0] 
    if form.is_valid():  
        form.save()  
        return redirect("/show")
    return render(request, 'show.html', {'form': form}) 

def destroy(request, id):  
    ticket = TicketBookModel.objects.get(id=id)  
    ticket.delete()  
    return redirect("/show") 