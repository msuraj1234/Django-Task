from application.models import Student
from django.shortcuts import render
from application.models import Student
import datetime

# Create your views here.
def home(request):
    return render(request, 'home.html')

def index(request):
    if request.method == "POST":
        name = request.POST.get('name')
        mail = request.POST.get('mail')
        contact = request.POST.get('contact')
        address = request.POST.get('address')
        student = Student(name=name, mail=mail, contact=contact, address=address, date = datetime.datetime.today())
        student.save()
        
    return render(request,'index.html')

def about(request):
    test = Student.objects.all()
    return render(request, 'about.html', {'test': test})
